create view e as
  select
    `u`.`u_id`        AS `u_id`,
    `u`.`u_password`  AS `u_password`,
    `u`.`u_tel`       AS `u_tel`,
    `u`.`u_state`     AS `u_state`,
    `u`.`u_nick_name` AS `u_nick_name`,
    `u`.`u_time`      AS `u_time`,
    `u`.`u_real_name` AS `u_real_name`,
    `u`.`u_id_card`   AS `u_id_card`
  from `qenergy`.`u`;

