create view u as
  select
    `qenergy`.`user`.`u_id`        AS `u_id`,
    `qenergy`.`user`.`u_password`  AS `u_password`,
    `qenergy`.`user`.`u_tel`       AS `u_tel`,
    `qenergy`.`user`.`u_state`     AS `u_state`,
    `qenergy`.`user`.`u_nick_name` AS `u_nick_name`,
    `qenergy`.`user`.`u_time`      AS `u_time`,
    `qenergy`.`user`.`u_real_name` AS `u_real_name`,
    `qenergy`.`user`.`u_id_card`   AS `u_id_card`
  from `qenergy`.`user`;

