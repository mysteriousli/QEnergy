create view q as
  select `qenergy`.`bill`.`b_id` AS `b_id`
  from `qenergy`.`bill`;

