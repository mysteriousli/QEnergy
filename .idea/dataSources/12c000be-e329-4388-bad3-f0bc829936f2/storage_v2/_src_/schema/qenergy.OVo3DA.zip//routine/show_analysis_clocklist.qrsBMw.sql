create procedure show_analysis_clockList(IN u_id int)
  BEGIN
	#Routine body goes here...
	DECLARE totalDuration INT;
	SELECT SUM(c_duration) INTO totalDuration FROM tomato WHERE tomato.u_id=u_id AND tomato.c_full=1;
	Select tomato.c_label,SUM(tomato.c_duration) from tomato WHERE tomato.u_id=u_id
	and c_full=1 GROUP BY c_label;
END;

