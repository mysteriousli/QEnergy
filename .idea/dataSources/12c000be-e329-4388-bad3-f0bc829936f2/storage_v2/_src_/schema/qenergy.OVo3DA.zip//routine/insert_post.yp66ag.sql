create procedure insert_post(IN userId int, IN content longtext)
  BEGIN
	#Routine body goes here...
	DECLARE user_name VARCHAR(20);
	DECLARE id int(20);
	SELECT `user`.u_nick_name into user_name from user WHERE user.u_id = userId;
	insert into post(post.u_id,post.u_name,post.p_content,post.p_date) VALUES(userId,user_name,content,NOW());
	select LAST_INSERT_ID();
END;

