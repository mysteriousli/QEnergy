create trigger like_delete
  before DELETE
  on fabulous
  for each row
  update post set post.p_like=post.p_like-1 where old.f_post=post.p_id;

