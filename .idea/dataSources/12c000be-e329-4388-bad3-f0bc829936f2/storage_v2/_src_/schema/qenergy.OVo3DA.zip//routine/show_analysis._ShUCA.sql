create procedure show_analysis(IN u_id int)
  BEGIN
	#Routine body goes here...
	DECLARE totalClock INT(20);
	DECLARE totalDuration INT(20);
	DECLARE todayDuration INT(20);
	DECLARE todayClock INT(20);
	SELECT COUNT(*) INTO totalClock from tomato WHERE tomato.c_full=1 AND tomato.u_id=u_id;
	SELECT SUM(tomato.c_duration) into totalDuration FROM tomato WHERE tomato.c_full=1 and tomato.u_id=u_id;
	SELECT COUNT(*),SUM(tomato.c_duration) INTO todayClock,todayDuration FROM tomato WHERE TIMESTAMPDIFF(DAY,tomato.c_start,NOW())=0 AND tomato.u_id=u_id and tomato.c_full=1;
	SELECT totalClock,totalDuration,todayClock,todayDuration;
END;

