create trigger like_insert
  after INSERT
  on fabulous
  for each row
  update post set p_like=p_like+1 where new.f_post = post.p_id;

